//
//  ContentView.swift
//  CatsAndModules_ViktorSoviak
//
//  Created by Viktor Sovyak on 5/20/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("dsa")
    }
}

#Preview {
    ContentView()
}
